from django.apps import AppConfig


class TaConfig(AppConfig):
    name = 'ta'
