from django.contrib import admin
from .models import Ads
# Register your models here.


# Register your models here.
admin.site.register(Ads)
