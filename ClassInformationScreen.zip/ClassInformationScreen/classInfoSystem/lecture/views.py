from django.shortcuts import render
from django.http import HttpResponse
from .models import *
from lecture.models import *
from department.models import *
from ads.models import *
from student.models import *
from datetime import datetime
import pytz


